config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

config etc/pam.d/lightdm.new
config etc/pam.d/lightdm-autologin.new
config etc/pam.d/lightdm-greeter.new
config etc/lightdm/lightdm.conf.d/50-directories.conf.new
config etc/lightdm/lightdm.conf.d/50-slarm64-defaults.conf.new
config etc/lightdm/keys.conf.new
config etc/lightdm/lightdm.conf.new
config etc/lightdm/users.conf.new
config etc/dbus-1/system.d/org.freedesktop.DisplayManager.conf.new
config usr/share/polkit-1/rules.d/lightdm.rules.new

if ! grep ^lightdm: etc/passwd 1> /dev/null 2> /dev/null ; then
  echo "lightdm:x:620:620:LightDM:/var/lib/lightdm:/bin/false"
fi
if ! grep ^lightdm: etc/group 1> /dev/null 2> /dev/null ; then
  echo "lightdm::620:" >> etc/group
fi
if ! grep ^lightdm: etc/shadow 1> /dev/null 2> /dev/null ; then
  echo "lightdm:*:9797:0:::::" >> etc/shadow
fi

if [[ ! $(grep lightdm etc/rc.d/rc.4 2>/dev/null) ]];then
sed '0,/^# Look for SDDM as well\:.*$/s/^# Look for SDDM as well\:.*$/# Look for LightDM as well\:\
if \[ -x \/usr\/bin\/lightdm \]; then\
  exec \/usr\/bin\/lightdm 2\>\/dev\/null\
fi\n\n&/g' -i etc/rc.d/rc.4
fi
