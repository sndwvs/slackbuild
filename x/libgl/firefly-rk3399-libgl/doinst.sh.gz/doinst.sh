
if [[ ! $(grep mali-egl etc/ld.so.conf) ]];then
    sed -e '/^\/lib/a\/usr/lib/mali-egl' etc/ld.so.conf
fi
