sed -i '/mali-egl/d' etc/ld.so.conf
sed -i '/^\/lib/a\/usr/lib/mali-egl' etc/ld.so.conf
